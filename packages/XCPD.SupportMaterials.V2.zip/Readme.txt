XCPD Support Materials:
Version 1: 9/18/2009 - Initial version, has not been schema validated yet.
Version 2: 10/30/2009 - Fixed missing namespaces on elements and added comments on optional sections