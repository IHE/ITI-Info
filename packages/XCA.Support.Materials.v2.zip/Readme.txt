XCA Support Materials:
Version 1: 4/22/2008 - Initial version
Version 2: 5/16/2008 - Updated Cross Gateway Retrieve example to use same homeCommunityId for both documents retrieved.