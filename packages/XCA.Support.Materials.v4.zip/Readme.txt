XCA Support Materials:
Version 1: 4/22/2008 - Initial version
Version 2: 5/16/2008 - Updated Cross Gateway Retrieve example to use same homeCommunityId for both documents retrieved.
Version 3: 9/24/2008 - Updated RespondingGateway.wsdl (removed SOAP 1.1 support & added Async support) and added InitiatingGateway.wsdl (in support of Async)
Version 4: 12/9/2008 - Fixed in response to problems found by implementors
	a) Typo fixed in InitatingGateway
	b) Added XDS Affinity Domain Option to RespondingGateway as the default, commented out support for Asynchronous Web Services Exchange.  The logic here is that the XDS Affinity Domain Option is expected to be the most common one implemented.  The Async option is expected to be less commonly implemented.  But the content is there and just needs to be uncommented to be used.
	c) Broke both Initiating and Responding Gateway WSDL into two peices, one for the query path and separate for the retrieve path.  This is because the query is simple SOAP and retrieve is MTOM/XOP.  Some platforms may require separate service endpoints for simple SOAP and MTOM/XOP so the breakup of the wsdl files enables that.
	d) Added XCA to the file name to be consistent with other IHE ITI profiles