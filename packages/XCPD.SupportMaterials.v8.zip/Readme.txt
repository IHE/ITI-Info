XCPD Support Materials:
Version 1: 9/18/2009 - Initial version, has not been schema validated yet.
Version 2: 10/30/2009 - Fixed missing namespaces on elements and added comments on optional sections
Version 3: 12/10/2009 - Fixed XCPD_PLQ.xsd to have proper references to hl7 data types and fixed typos. Fixed XCPDRespondingGateway.wsdl to include XCPD_PLQ.xsd.  With this changes JAX-WS is able to parse, validate and generate code correctly from the WSDL.
Version 4: 12/07/2010 - Fixed typo in wsdl, fixed typos in examples
Version 5: 03/10/2011:
	- Added XCPDCrossGatewayPatientDiscoveryResponseAEError.xml example
	- Fixed error in XCPDCrossGatewayPatientDiscoveryResponseForMoreDemographics.xml example fix from CP 535
	- Fixed error in XCPDCrossGatewayPatientDiscoveryRequest.xml reflecting fix from CP 572
	- Updated WSDL for Deferred Response support
	- Examples of Deferred Response messages
Version 6: 10/25/2011 - Fixed typos in Initiating Gateway WSDL and Responding Gateway WSDL
Version 7: 12/21/2011 - Added Revoke example and updated Deferred_RequestAck and Deferred_ResponseAck to conform to schema
Version 8: 10/03/2012 - Added Revoke entries to WSDL and Revoke schema file PRPA_IN201303UV02.xsd. Likely missing dependencies of PRPA_IN201303UV02 - will add as they are identified.
	- Also fixed a bunch of typos in WSDL