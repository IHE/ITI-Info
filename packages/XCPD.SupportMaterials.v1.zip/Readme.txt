XCPD Support Materials:
Version 1: 9/18/2009 - Initial version, has not been schema validated yet.
